// it is a typescript file with extension .ts
// .ts ---> tsc(TS compiler) ---> .js ---> it can be executed on any JS runtime env (browsers, node.js, Apps)

/**
 *  This block explains the purpose of the file.
 * It is commonly used at the top of files.
 */


console.log("Hey There!");

