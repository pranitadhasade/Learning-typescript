function testname(){
    if (fname.lenght>32){
        console.log("Pass");
    }
    else{
        console.log("Fail");
    }

}

testname();